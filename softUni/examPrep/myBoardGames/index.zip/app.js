const BASE_URL = 'http://localhost:3030/jsonstore/games/';

const nameInputEl = document.querySelector('#g-name');
const typeInputEl = document.querySelector('#type');
const playersInputEl = document.querySelector('#players');
const gamesListDiv = document.querySelector('#games-list');

const addGameBtn = document.querySelector('#add-game');
const editGameBtn = document.querySelector('#edit-game');
const loadGameBtn = document.querySelector('#load-games');
const changeBtn = document.querySelector('.change-btn');
const deleteBtn = document.querySelector('.delete-btn');

let selectedGameId = null;  // to save the gameId from handleLoadEdit fumction


loadGameBtn.addEventListener('click', handleLoadGames);
addGameBtn.addEventListener('click', handleAddGame);
editGameBtn.addEventListener('click', handleEditGame);

async function handleLoadGames() {
    const gamesRes = await fetch(BASE_URL);
    const gamesData = await gamesRes.json();
    const gamesArr = Object.values(gamesData);
    gamesListDiv.innerHTML = '';  // delete the hardcoded game

    gamesArr.forEach(gameObj => {
        const boardGameDivEl = document.createElement('div');
        boardGameDivEl.classList.add('board-game');

        const contentDivEl = document.createElement('div');
        contentDivEl.classList.add('content');

        const namePEl = document.createElement('p');
        namePEl.textContent = gameObj.name;

        const playersPEl = document.createElement('p');
        playersPEl.textContent = gameObj.players;

        const typePEl = document.createElement('p');
        typePEl.textContent = gameObj.type;

        const btnsContainerDiv = document.createElement('div');
        btnsContainerDiv.classList.add('buttons-container');

        const newChangeBtnEl = document.createElement('button');
        newChangeBtnEl.classList.add('change-btn');
        newChangeBtnEl.textContent = 'Change';

        const newDeleteBtnEl = document.createElement('button');
        newDeleteBtnEl.classList.add('delete-btn');
        newDeleteBtnEl.textContent = 'Delete';

        gamesListDiv.appendChild(boardGameDivEl);
        boardGameDivEl.appendChild(contentDivEl);
        contentDivEl.appendChild(namePEl);
        contentDivEl.appendChild(playersPEl);
        contentDivEl.appendChild(typePEl);

        boardGameDivEl.appendChild(btnsContainerDiv);
        btnsContainerDiv.appendChild(newChangeBtnEl);
        btnsContainerDiv.appendChild(newDeleteBtnEl);

        newChangeBtnEl.addEventListener('click', handleLoadEdit);

        newDeleteBtnEl.addEventListener('click', handleDeleteGame);

        async function handleDeleteGame() {
            await fetch(`${BASE_URL}/${gameObj._id}`, {
                method: 'DELETE'
            });
            
            await handleLoadGames();
        }

        function handleLoadEdit() {
            nameInputEl.value = gameObj.name;
            typeInputEl.value = gameObj.type;
            playersInputEl.value = gameObj.players;

            editGameBtn.disabled = false;
            addGameBtn.disabled = true;

            selectedGameId = gameObj._id;
        }
    });
}

async function handleAddGame() {
    const name = nameInputEl.value.trim();
    const type = typeInputEl.value.trim();
    const players = playersInputEl.value.trim();

    await fetch(BASE_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, type, players })
    });

    nameInputEl.value = '';
    typeInputEl.value = '';
    playersInputEl.value = '';

    await handleLoadGames();
}

async function handleEditGame() {
    const name = nameInputEl.value.trim();
    const type = typeInputEl.value.trim();
    const players = playersInputEl.value.trim();

    await fetch(`${BASE_URL}/${selectedGameId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({name, type, players})
    });

    nameInputEl.value = '';
    typeInputEl.value = '';
    playersInputEl.value = '';

    selectedGameId = null;
    
    addGameBtn.disabled = false;
    editGameBtn.disabled = true;

    await handleLoadGames();
}

